import { useState } from "react";
import Group from '../models/group';
import Form, { Button, Select, Text } from "../components/Form";
import Panel from "../components/Panel";
import Alert from "../components/Alert";
import { isAuthenticated } from "../lib/authenticated";

export default function ({ groupOptions }) {
    const [isNew, setIsNew] = useState(groupOptions[0].value === 'new');
    const [alertShown, setAlertShown] = useState(false);

    const successAlert = <Alert text='Added Successfully' type='success' />;

    const handleSubmit = async e => {
        e.preventDefault();
        const form = e.target;
        const action = form.action;
        const data = new FormData(form);
        const body = new URLSearchParams(data).toString();

        const response = await fetch(action, {
            method: 'POST',
            body,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        });
        const responseJson = await response.json();

        if (responseJson.done) {
            setAlertShown(true);
            setInterval(() => setAlertShown(false), 5000);
            form.reset();
        }

    };

    return (
        <Panel title='Add Device' active='add-device'>
            <Form action={isNew ? 'api/new-group' : 'api/update-group'} onSubmit={handleSubmit}>
                <Select
                    label='Group'
                    name={isNew ? 'group0' : 'group'}
                    options={groupOptions}
                    onValueChange={value => setIsNew(value === 'new')}
                />
                {isNew &&
                    <Text
                        label='New Group Name'
                        name='group'
                    />
                }
                <Text
                    label='Device ID'
                    name='deviceId'
                />
                <Button
                    text='Add'
                    type='submit'
                />
            </Form>
            {alertShown && successAlert}
        </Panel>
    );
}

export async function getServerSideProps(ctx) {
    if (! await isAuthenticated(ctx.req, ctx.res))
        return {
            redirect: {
                destination: "/login",
                permanent: false,
            },
        };

    const groups = await Group.find().select({ name: 1, _id: 0 }).exec();

    const groupOptions = groups.map(group => ({
        label: group.name,
        value: group.name
    }));

    groupOptions.push({ label: 'New', value: 'new' });

    return {
        props: { groupOptions }
    }
}