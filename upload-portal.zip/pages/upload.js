import Group from '../models/group';
import Form, { Button, File, Select } from "../components/Form";
import Panel from "../components/Panel";
import { isAuthenticated } from "../lib/authenticated";
import { useState } from 'react';
import Progress from '../components/Progress';

export default function({ groupOptions }) {
    const [progress, setProgress] = useState(-1);
    const [total, setTotal] = useState(-1);

    const uploadFile = e => {
        e.preventDefault();

        const form = e.target;
        const action = form.action;
        const data = new FormData(form);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', action);
        xhr.upload.addEventListener('progress', e => {
            setProgress(e.loaded);
            setTotal(e.total);
        });
        xhr.addEventListener('load', e => {
            setProgress(200);
            setTotal(200);
            console.log("Done");
            console.log(progress, total);
        });
        xhr.send(data);
    }

    return (
        <Panel title='Upload File' active='upload'>
            <Form action='api/upload' enctype='multipart/form-data' onSubmit={uploadFile}>
                <Select
                    label='Group'
                    name='group'
                    options={ groupOptions }
                />
                <File label='File' name='file' />
                <Button text='Upload' type='submit' />
                {progress > -1 &&
                    <Progress complete={progress} total={total} />
                }
            </Form>
        </Panel>
    );
}

export async function getServerSideProps(ctx) {
    if (! await isAuthenticated(ctx.req, ctx.res))
        return {
            redirect: {
                destination: "/login",
                permanent: false,
            },
        };
    
    const groups = await Group.find().select({ name: 1, _id: 0 }).exec();

    const groupOptions = groups.map(group => ({
        label: group.name,
        value: group.name
    }));

    return {
        props: { groupOptions }
    }
}