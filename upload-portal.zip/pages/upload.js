import Group from '../models/group';
import Form, { Button, File, Select } from "../components/Form";
import Panel from "../components/Panel";
import { isAuthenticated } from "../lib/authenticated";

export default function({ groupOptions }) {
    return (
        <Panel title='Upload File' active='upload'>
            <Form action='api/upload' enctype='multipart/form-data'>
                <Select
                    label='Group'
                    name='group'
                    options={ groupOptions }
                />
                <File label='File' name='file' />
                <Button text='Upload' type='submit' />
            </Form>
        </Panel>
    );
}

export async function getServerSideProps(ctx) {
    if (! await isAuthenticated(ctx.req, ctx.res))
        return {
            redirect: {
                destination: "/login",
                permanent: false,
            },
        };
    
    const groups = await Group.find().select({ name: 1, _id: 0 }).exec();

    const groupOptions = groups.map(group => ({
        label: group.name,
        value: group.name
    }));

    return {
        props: { groupOptions }
    }
}