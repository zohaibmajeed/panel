import '../styles.css';

export default function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />
}

export async function getServerSideProps(req, res) {
  console.log(req, res);
  return {
    props: {}
  }
}