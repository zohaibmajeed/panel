import Group from "../models/group";
import Panel from "../components/Panel";
import { Box, Boxes } from "../components/Box";
import { isAuthenticated } from "../lib/authenticated";

export default function({ devicesCount, filesCount, groupsCount }) {
    return (
        <Panel title='Dashboard' active='dashboard'>
            <Boxes>
                <Box href='devices' icon='devices' label='Devices' value={ devicesCount } />
                <Box href='devices' icon='file_copy' label='Files' value={ filesCount } />
                <Box href='devices' icon='group' label='Groups' value={ groupsCount } />
            </Boxes>
        </Panel>
    );
}

export async function getServerSideProps(ctx) {
    if (! await isAuthenticated(ctx.req, ctx.res))
        return {
            redirect: {
                destination: "/login",
                permanent: false,
            },
        };
        
    let devicesCount = 0, filesCount = 0, groupsCount = 0;

    const groups = await Group.find().select({ devices: 1, file: 1, _id: 0 }).exec();
    groups.forEach(group => {
        devicesCount += group.devices.length;
        if (group?.file) filesCount++;
    });
    groupsCount = groups.length;

    return {
        props: { devicesCount, filesCount, groupsCount }
    }
}