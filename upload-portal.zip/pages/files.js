import GroupModel from '../models/group';
import Panel from "../components/Panel";
import { isAuthenticated } from "../lib/authenticated";

export default function({ groups }) {
    return (
        <Panel title='Files' active='files'>
            <table className='table'>
                <thead>
                    <tr>
                        <th>Group Name</th>
                        <th>Download</th>
                    </tr>
                </thead>
                <tbody>
                    {groups.map(group =>
                        <tr key={ group._id }>
                            <td>{ group.name }</td>
                            <td>
                                <a href={`api/download-content?deviceId=${group.devices[0]}`}>Download</a>
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </Panel>
    );
}

export async function getServerSideProps(ctx) {
    if (! await isAuthenticated(ctx.req, ctx.res))
        return {
            redirect: {
                destination: "/login",
                permanent: false,
            },
        };

    const groups = await GroupModel.find({
        file: { $ne: '' }
    }).select({ name: 1, file: 1, devices: 1, _id: 1 }).exec();
    const go = JSON.parse( JSON.stringify(groups) );

    return {
        props: { groups: go }
    }
}