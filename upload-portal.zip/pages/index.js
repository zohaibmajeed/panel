export default function IndexPage() {
    return <h1>Hello World</h1>;
}

export async function getServerSideProps(ctx) {
    return {
        redirect: {
            destination: "/dashboard",
            permanent: false,
        },
    };
}