import Group from "../../models/group";

export default async function(req, res) {
    const { name, deviceId } = req.body;

    const group = await Group.findOne({ name, devices: deviceId }).exec();

    group.devices = group.devices.filter(device => deviceId !== device);

    if (group.devices.length === 0) {
        await group.deleteOne();
    } else {
        await group.save();
    }


    res.json({ done: true });
}