import Group, { connection } from '../../models/group';

export default async function(req, res) {
    await connection;
    const groups = await Group.find().exec();
    res.json(groups);
}