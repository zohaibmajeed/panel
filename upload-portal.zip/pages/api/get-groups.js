import Group from '../../models/group';

export default async function(req, res) {
    const groups = await Group.find().exec();
    res.json(groups);
}