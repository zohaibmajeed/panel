import crypto from 'crypto';
import fsp from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import formidable from "formidable";
import { v4 as uuidv4 } from 'uuid';
import Group from "../../models/group";

function parseForm(req) {
    return new Promise((resolve, reject) => {
        const form = new formidable.IncomingForm();
        const whenParsed = (err, fields, files) => {
            if (err) {
                reject(err);
            } else {
                resolve([fields, files])
            }
        };
        form.parse(req, whenParsed);
    });
}

async function moveFile(file) {
    const extension = path.extname(file.originalFilename);
    const lastname = uuidv4() + extension;
    const filename = path.join(
        path.dirname(fileURLToPath(import.meta.url)),
        '../..',
        'uploads',
        lastname
    );
    await fsp.rename(file.filepath, filename);
    return [lastname, filename];
}

export default async function(req, res) {
    if (req.method.toLowerCase() === 'post') {
        const [fields, files] = await parseForm(req);
        const [path, fullPath] = await moveFile(files.file);
        const buffer = await fsp.readFile(fullPath);
        const hashSum = crypto.createHash('sha256');
        hashSum.update(buffer);
        const hash = hashSum.digest('hex');
        const group = await Group.findOne({ name: fields.group }).exec();
        group.file = path;
        group.hash = hash;
        await group.save();
        res.json({ done: true });
    } else {
        res.json({ done: false })
    }
}

export const config = {
    api: {
      bodyParser: false,
    },
  };