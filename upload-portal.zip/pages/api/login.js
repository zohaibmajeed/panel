import User from '../../models/user';
import { getSession } from '../../models/session';

export default async function(req, res) {
    const username = req.body.username;
    const password = req.body.password;

    const session = await getSession(req, res);

    const record = await User.findOne({ username }).exec();

    if (record && record.password === password) {
        session.loggedIn = true;
        session.username = username;
        res.redirect('../dashboard');
    } else {
        res.redirect('../login');
    }

}