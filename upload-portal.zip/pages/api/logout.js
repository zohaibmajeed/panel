import { getSession } from '../../models/session';

export default async function(req, res) {
    const session = await getSession(req, res);
    session.loggedIn = false;
    session.username = '';
    res.redirect('../login');
}