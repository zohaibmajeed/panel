import Group from "../../models/group";

export default async function(req, res) {
    const { group: name, deviceId } = req.body;

    const group = await Group.findOne({ name }).exec();
    group.devices.push(deviceId)
    await group.save();

    res.json({ done: true });
}