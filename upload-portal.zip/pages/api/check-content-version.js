import Group from "../../models/group";

export default async function(req, res) {
    const deviceId = req.query.deviceId;
    const record = await Group.findOne({ devices: deviceId }).exec();
    if (record && record.file) res.json({ found: true, hash: record.hash });
    else res.status(401).json({ found: false });
}