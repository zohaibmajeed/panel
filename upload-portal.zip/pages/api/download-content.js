import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import Group from "../../models/group";

export default async function(req, res) {
    const deviceId = req.query.deviceId;
    const record = await Group.findOne({ devices: deviceId }).exec();
    if (record && record.file) {
        const filename = path.join(
            path.dirname(fileURLToPath(import.meta.url)),
            '../..',
            'uploads',
            record.file
        );
        const stream = fs.createReadStream(filename);
        stream.pipe(res);
    } else {
        res.status(401).json({ found: false });
    }
}