import Group from "../../models/group";

export default async function(req, res) {
    const { group: name, deviceId } = req.body;

    const group = new Group({
        name,
        devices: [deviceId]
    });
    await group.save();

    res.json({ done: true });
}