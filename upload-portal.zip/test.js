// import mongoose from 'mongoose';

// (async () => {
//     const { Schema } = mongoose;
//     console.log("Connecting!!!");
//     const db = await mongoose.connect('mongodb://127.0.0.1:27017/uploadportal');
//     console.log("Connected!!");
    
//     const schema = new Schema({
//         name: String,
//         devices: [String],
//         file: String
//     });
    
//     const Group = mongoose.model('Group', schema);

//     const group = new Group({
//         name: "KAKA"
//     });
    
//     await group.save();
//     console.log("Saved");
// })();

// import Group, { connection } from "./models/group.js";

// (async () => {
//     await connection;
//     console.log("Connected");

//     const group = new Group({
//         name: "Dummy Name",
//         devices: ['jhdjhkshkhkj']
//     });
    
//     await group.save();
//     console.log("Saved");
// })();

(async () => {
    const response = await fetch('http://localhost:3000/api/get-groups');
    const responseJson = await response.json();
    console.log(responseJson);
})();