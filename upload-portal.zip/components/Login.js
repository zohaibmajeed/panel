import { Button, Text } from './Form';
import styles from './Login.module.css';

export default function Login() {
    return (
        <div className={styles.page}>
            <form className={styles.box} method='POST' action='api/login'>
                <Text label='Username' name='username' type='text' />
                <Text label='Password' name='password' type='password' />
                <Button type='submit' text='Login' />
            </form>
        </div>
    );
}