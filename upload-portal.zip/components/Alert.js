import styles from './Alert.module.css';

export default function Alert({ text, type }) {
    return (
        <div className={`${styles.alert} ${type === 'success' ? styles.success : styles.error}`}>
            { text }
        </div>
    )
}