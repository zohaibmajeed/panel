import Link from "next/link";
import Icon from "./Icon";
import styles from './Box.module.css';

export function Boxes({ children }) {
    return <div className={ styles.boxes }>{ children }</div>;
}

export function Box({ icon, label, value, href = '' }) {
    return (
        <Link href={ href } className={ styles.box }>
            <div className={ styles.left }>
                <Icon name={ icon } className={ styles.icon } />
            </div>
            <div className={ styles.right }>
                <div>{ label }</div>
                <div>{ value }</div>
            </div>
        </Link>
    )
}