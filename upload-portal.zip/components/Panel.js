import Head from 'next/head'
import Sidebar from './Sidebar';
import styles from './Panel.module.css';
import Link from 'next/link';

export default function Panel({ title, children, active }) {
    return (
        <>
            <Head>
                <title>{ title }</title>
            </Head>
            <div className={styles.panel}>
                <Sidebar active={ active } />
                <Link href='api/logout' className={styles.logout}>Logout</Link>
                <div className={styles.content}>
                    <div className={styles.contentTop}>
                        <h1 className={styles.heading}>{ title }</h1>
                    </div>
                    {children}
                </div>
            </div>
        </>
    );
}