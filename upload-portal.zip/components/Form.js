import styles from './Form.module.css';

export function Text({ label, name, type = 'text' }) {
    return (
        <div className={styles.field}>
            <label htmlFor={ name } className={ styles.label }>{ label }</label>
            <input type={ type } name={ name } id={ name } className={ styles.input } />
        </div>
    );
}

export function Select({ label, name, options, onValueChange }) {

    const handleChange = e => onValueChange && onValueChange(e.target.value);

    return (
        <div className={styles.field}>
            <label htmlFor={ name } className={ styles.label }>{ label }</label>
            <select id={ name } name={ name } className={ styles.input } onChange={ handleChange }>
                {options.map((option, i) => 
                    <option value={ option.value } key={i} disabled={ !!option?.disabled }>{ option.label }</option>
                )}
            </select>
        </div>
    );
}

export function File({ label, name }) {
    return (
        <div className={styles.field}>
            <label htmlFor={ name } className={ styles.label }>{ label }</label>
            <input type='file' name={ name } id={ name } className={ styles.input } />
        </div>
    );
}

export function Button({ text, type, onClick = () => undefined, noContainer }) {
    const button = <button type={ type } className={styles.button} onClick={onClick}>{ text }</button>;
    return noContainer ?
        button : 
        <div className={styles.field}>{ button }</div>;
}

export default function Form({ action = '', children, onSubmit = () => undefined, enctype }) {
    return <form className={styles.form} action={ action } method='post' onSubmit={ onSubmit } encType={ enctype }>
        { children }
    </form>
}