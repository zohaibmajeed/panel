import styles from './Progress.module.css';

export default function Progress({ complete, total }) {
    const progress = ( (complete / total) * 100 ).toFixed(2);
    const percentage = `${progress}%`;
    const uploaded = (complete === total);

    return <>
        <div>
            <i>{uploaded ? 'Upload Complete' : 'Uploading..'}.</i>
        </div>
        {!uploaded && 
            <div className={styles.progressContainer}>
                <div className={styles.progress} style={{ width: percentage }}></div>
            </div>
        }
    </>
}