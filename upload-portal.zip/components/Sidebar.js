import Link from 'next/link';
import Icon from './Icon';
import styles from './Sidebar.module.css';

function Items({ children, inner = false }) {
    return children && (
        <ul
            className={`${styles.ul} ${inner ? styles.inner : ''}`}
        >
            { children }
        </ul>
    );
}

function Item({ href, name, icon, active, children }) {
    return (
        <>
            <li className={styles.li}>
                <Link href={href} className={`${styles.link} ${active ? styles.active : ''}`}>
                    {icon && <Icon name={icon} className={styles.mainIcon} /> }
                    <span>{name}</span>
                    {children && <Icon name='expand_more' className={styles.moreIcon} />}
                </Link>
                <Items inner={true}>{ children }</Items>
            </li>
        </>
    )
}

export default function Sidebar({ active = 'dashboard' }) {
    return (
        <div className={styles.sidebar}>
            <Items>
                <Item href='dashboard' name='Dashboard' icon='dashboard' active={ active === 'dashboard' } />
                <Item href='devices' name='All Devices' icon="devices" active={ active === 'devices' } />
                <Item href='add-device' name='Add Device' icon="add" active={ active === 'add-device' } />
                <Item href='upload' name='Upload File' icon='upload' active={ active === 'upload' } />
            </Items>
        </div>
    );
}