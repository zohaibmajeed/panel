import { useState } from 'react';
import Icon from './Icon';
import { Button } from './Form';
import styles from './Group.module.css';

export default function Group({ name, devices: d }) {
    const [hidden, setHidden] = useState(true);
    const [devices, setDevices] = useState(d);

    const deleteDevice = async (deviceId) => {
        const params = new URLSearchParams();
        params.append('name', name);
        params.append('deviceId', deviceId);

        const action = 'api/delete-device';
        const body = params.toString();

        const response = await fetch(action, {
            method: 'POST',
            body,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        });
        const responseJson = await response.json();

        if (responseJson.done) {
            setDevices(
                devices.filter(val => val !== deviceId)
            );
        }

        console.log(responseJson);
    }

    if (devices.length === 0) return;

    return (
        <div className={styles.group}>
            <div className={styles.name} onClick={() => setHidden(!hidden)}>
                { name }
                <Icon name='expand_more' className={ styles.icon } />
            </div>
            {!hidden &&
                <div className={styles.content}>
                    <table className={ styles.table }>
                        <tbody>
                            <tr>
                                <th>Device Id</th>
                                <th>
                                    Delete
                                </th>
                            </tr>
                            {devices.map(device =>   
                                <tr key={ device }>
                                    <td>{ device }</td>
                                    <td>
                                        <Button text='Delete' type='button' onClick={ () => deleteDevice(device) } noContainer />
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            }
        </div>
    );
}