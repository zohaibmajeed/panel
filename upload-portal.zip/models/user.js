import { Schema, model, mongoose } from './connection';

const schema = new Schema({
    username: String,
    password: String
});

const Group = mongoose.models.User || model('User', schema);

export default Group;