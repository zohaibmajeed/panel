import { Schema, model, mongoose } from './connection';

const schema = new Schema({
    name: String,
    devices: [String],
    file: String,
    hash: String
});

const Group = mongoose.models.Group || model('Group', schema);

export default Group;