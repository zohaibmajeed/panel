import nextSession from "next-session";
import { Schema, model, mongoose } from './connection';

const schema = new Schema({
    sessId: String,
    data: Object
});

const Session = mongoose.models.Session || model('Session', schema);

export default Session;

export class Store {
    async get(sessId) {
        const record = await Session.findOne({ sessId }).exec();
        if (record) return record.data;
        return null;
    }

    async set(sessId, data) {
        let record = await Session.findOne({ sessId }).exec();
        
        if (!record) {
            record = new Session();
            record.sessId = sessId;
        }

        record.data = data;
        await record.save();
    }

    async destroy(sessId) {
        const record = await Session.findOne({ sessId }).exec();
        if (record) await record.deleteOne();
    }

    async touch(sessId, data) {
        await this.set(sessId, data);
    }
}

export const getSession = nextSession({
    store: new Store()
});